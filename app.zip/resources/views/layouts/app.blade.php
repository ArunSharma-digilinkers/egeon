@include('inc.header')
@include('inc.navbar')

<!-- Page Content -->
<main>
    <div class="">
        @yield('content')
    </div>
</main>

@include('inc.footer')
