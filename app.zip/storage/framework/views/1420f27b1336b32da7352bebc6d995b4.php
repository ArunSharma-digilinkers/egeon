

<?php $__env->startSection('content'); ?>

<div class="admin-page">

    
    <div class="page-header section-entry">
        <div>
            <h1>Update Product</h1>
            <p class="text-muted">Edit product information</p>
        </div>

        <a href="<?php echo e(route('product.index')); ?>" class="btn btn-outline-secondary">
            ← Back to Products
        </a>
    </div>

    
    <div class="card admin-card">
        <div class="card-body">

            
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('product.update', $product->id)); ?>"
                  method="POST"
                  enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">

                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Category</label>
                        <select name="category" class="form-control" required>
                            <option value="inverter" <?php echo e($product->category === 'inverter' ? 'selected' : ''); ?>>
                                Inverter Batteries
                            </option>
                            <option value="rickshaw" <?php echo e($product->category === 'rickshaw' ? 'selected' : ''); ?>>
                                Rickshaw Batteries
                            </option>
                            <option value="bike" <?php echo e($product->category === 'bike' ? 'selected' : ''); ?>>
                                Bike Batteries
                            </option>
                        </select>
                    </div>

                    
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Model</label>
                        <input type="text"
                               name="model"
                               class="form-control"
                               value="<?php echo e(old('model', $product->model)); ?>"
                               required>
                    </div>

                    
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Voltage</label>
                        <input type="text"
                               name="voltage"
                               class="form-control"
                               value="<?php echo e(old('voltage', $product->voltage)); ?>">
                    </div>

                    
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Capacity</label>
                        <input type="text"
                               name="capacity"
                               class="form-control"
                               value="<?php echo e(old('capacity', $product->capacity)); ?>">
                    </div>

                    
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Warranty</label>
                        <input type="text"
                               name="warranty"
                               class="form-control"
                               value="<?php echo e(old('warranty', $product->warranty)); ?>">
                    </div>

                    
                    <div class="col-md-6 mb-4">
                        <label class="form-label">Product Image</label>
                        <input type="file"
                               name="image"
                               class="form-control"
                               accept="image/*">

                        <?php if($product->image): ?>
                            <div class="image-preview mt-2">
                                <img src="<?php echo e(asset('storage/product/'.$product->image)); ?>"
                                     class="img-thumbnail"
                                     width="120">
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

                
                <div class="form-actions">
                    <button type="submit" class="btn btn-success">
                        Update Product
                    </button>

                    <a href="<?php echo e(route('product.index')); ?>"
                       class="btn btn-light ms-2">
                        Cancel
                    </a>
                </div>

            </form>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\egeon\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>