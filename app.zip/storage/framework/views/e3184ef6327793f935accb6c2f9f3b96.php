

<?php $__env->startSection('title', 'Mission Batteries Blog | Latest Battery Insights'); ?>

<?php $__env->startSection('description', 'Explore the Mission Batteries blog for expert updates on inverter, solar, and automotive
battery technology, energy tips, and industry innovations in India.'); ?>

<?php $__env->startSection('keywords', ''); ?>

<?php $__env->startSection('content'); ?>

<div class="main-wrapper">
 <div class="page-banner">
    <div class="container">
        <div class="page-banner-content">
            <h2>Blogs</h2>
            <p>Insights, Updates & Industry Knowledge</p>
        </div>
    </div>
</div>


    <div class="blog-wrapper section-entry">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-12 mt-5">
                    <a href="<?php echo e(route('details.show', $item->slug)); ?>" class="blog-link">
                        
                        <div class="blog-card">

                            <div class="blog-card-img">
                                <img src="<?php echo e(asset('storage/blog/' . $item->featured_image)); ?>"
                                     alt="<?php echo e($item->post_title); ?>">
                            </div>

                            <div class="blog-card-content">
                                <span class="blog-date">
                                    <i class="fa-regular fa-calendar"></i>
                                    <?php echo e($item->created_at->format('d M Y')); ?>

                                </span>

                                <h5 class="blog-title"><?php echo e($item->post_title); ?></h5>

                                <p class="blog-excerpt">
                                    <?php echo Str::words($item->blog_post, 22, '...'); ?>

                                </p>

                                <span class="read-more">Read More →</span>
                            </div>

                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\egeon\resources\views/pages/blog.blade.php ENDPATH**/ ?>