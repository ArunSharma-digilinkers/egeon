<?php $__env->startSection('content'); ?>

<div class="banner-wrap">
    <img src="<?php echo e(asset('img/bike-banner.jpg')); ?>" class="img-fluid">
</div>


<div class="product-wrapper section-entry">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
                <div class="pro-header-box">
                    <h3>Bike Lithium Batteries</h3>
                    <p> 
                        Our range of Bike delivers an exciting blend of power, performance, and energy efficiency. These vehicles are designed to provide an eco-friendly alternative to traditional fuel-powered bikes, offering superior acceleration and low maintenance costs. With cutting-edge technology, our motorcycles are perfect for riders who want to enjoy the thrill of the road while reducing their carbon footprint.
                    </p>
                </div>
                <div class="why-choose-product">
                    <h3>Why Choose Egeone Bike Lithium Batteries</h3>
                    <p>
                        Egeone bike lithium batteries are a high-performance power solution built for electric two-wheelers, offering faster charging, longer lifespan, and superior energy efficiency compared to traditional lead-acid alternatives. Their lightweight design boosts bike performance and range, while advanced lithium-ion technology ensures thousands of charge cycles with minimal degradation.
                    </p>

                    <p>
                        <span>Longer Life Span :</span> Up to 2,000–3,000+ charge cycles, reducing replacement costs.
                    </p>

                    <p>
                        <span>Faster Charging :</span> Typically 2–4 hours for a full charge—much faster than lead-acid types.
                    </p>

                    <p>
                        <span>High Discharge Rate :</span> Provides better acceleration and performance, especially uphill.
                    </p>
                    
                </div>
            </div>
        </div>
    </div>
</div>


<div class="product-single-wrap mb-5">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 mt-4">
                <div class="product-card-wrap">
                    
                    <div class="img-product">
                        <img src="<?php echo e(asset('storage/product/' . $item->image)); ?>" alt="<?php echo e($item->model); ?>">
                    </div>

                    <div class="product-details">
                        <h4><?php echo e($item->model); ?></h4>
                    </div>

                    <div class="product-detail-btn">
                        <a href="<?php echo e(url('bike-battery', $item->id)); ?>">View Details</a>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\egeon\resources\views/pages/bike-batteries.blade.php ENDPATH**/ ?>