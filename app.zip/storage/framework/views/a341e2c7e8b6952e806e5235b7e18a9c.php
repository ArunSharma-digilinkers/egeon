<aside class="admin-sidebar">
    <div class="sidebar-header">
        <h2>
            <?php if(auth()->user()->role === 'company'): ?>
               <?php echo e(auth()->user()->name); ?>

            <?php elseif(auth()->user()->role === 'distributor'): ?>
               Distributor Panel <?php echo e(auth()->user()->name); ?>

            <?php elseif(auth()->user()->role === 'dealer'): ?>
                Dealer Panel
            <?php endif; ?>
        </h2>
    </div>

    <nav class="sidebar-nav">

        
        <?php if(auth()->user()->role === 'company'): ?>

            <a href="<?php echo e(route('company.dashboard')); ?>" class="nav-link">
                Dashboard
            </a>

             <a href="<?php echo e(route('product.create')); ?>" class="nav-link">
                Add Product
            </a>

             <a href="<?php echo e(route('product.index')); ?>" class="nav-link">
                View Product
            </a>

            <a href="<?php echo e(route('company.users.create')); ?>" class="nav-link">
                Create Users
            </a>

            <a href="<?php echo e(route('company.users.index')); ?>" class="nav-link">
                All Users
            </a>

             <a href="<?php echo e(route('company.warranties')); ?>" class="nav-link">
                All Warranties
            </a>


            <a href="<?php echo e(route('blog.index')); ?>" class="nav-link">
                Blog
            </a>

        
        <?php elseif(auth()->user()->role === 'distributor'): ?>

            <a href="<?php echo e(route('distributor.dashboard')); ?>" class="nav-link">
                Dashboard
            </a>

            <a href="<?php echo e(route('distributor.check-warranty')); ?>" class="nav-link">
                Warranties
            </a>

        
        <?php elseif(auth()->user()->role === 'dealer'): ?>

            <a href="<?php echo e(route('dealer.dashboard')); ?>" class="nav-link">
                Dashboard
            </a>

            <a href="<?php echo e(route('dealer.warranty.create')); ?>" class="nav-link">
                Register Warranty
            </a>
            <a href="<?php echo e(route('dealer.view-warranty')); ?>" class="nav-link">
               View Warranty
            </a>


        <?php endif; ?>

    </nav>

    <div class="sidebar-footer">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">
                Logout
            </button>
        </form>
    </div>
</aside>
<?php /**PATH C:\xampp\htdocs\egeon\resources\views/inc/admin-sidenav.blade.php ENDPATH**/ ?>