

<?php $__env->startSection('page-title', 'State Warranties'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid mt-3">

    <h4 class="mb-3">Warranties in <?php echo e(auth()->user()->state); ?></h4>

    
    <form method="GET" action="<?php echo e(route('distributor.check-warranty')); ?>" class="mb-3">
        <div class="row g-2">
            <div class="col-md-4">
                <input type="text"
                       name="serial_number"
                       value="<?php echo e(request('serial_number')); ?>"
                       class="form-control"
                       placeholder="Search by Serial Number">
            </div>
            <div class="col-md-2">
                <button class="btn btn-primary w-100">Search</button>
            </div>
        </div>
    </form>

    <div class="card shadow-sm">
        <div class="card-body p-0">
            <table class="table table-striped table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Dealer</th>
                        <th>Customer</th>
                        <th>Battery Model</th>
                        <th>Serial Number</th>
                        <th>Barcode</th>
                        <th>Warranty</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $warranties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warranty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="txt-cap"><?php echo e(strtolower($loop->iteration)); ?></td>
                        <td class="txt-cap"><?php echo e($warranty->dealer->name ?? '-'); ?></td>
                        <td class="txt-cap">
                            <?php echo e(strtolower($warranty->customer_name)); ?><br>
                            <small><?php echo e(strtolower($warranty->customer_mobile)); ?></small>
                        </td>
                        <td class="txt-cap"><?php echo e(strtolower($warranty->battery_model)); ?></td>
                        <td class="txt-cap"><?php echo e(strtolower($warranty->serial_number)); ?></td>
                        <td class="txt-cap">
                            <svg id="barcode-<?php echo e($warranty->id); ?>"></svg>
                        </td>
                        <td class="txt-cap">
                            <?php echo e($warranty->warranty_start->format('d M Y')); ?> → 
                            <?php echo e($warranty->warranty_end->format('d M Y')); ?>

                        </td>
                        <td class="txt-cap">
                            <?php if(now()->lte($warranty->warranty_end)): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Expired</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-4">
                            No warranties found.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
<script>
<?php $__currentLoopData = $warranties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warranty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    JsBarcode("#barcode-<?php echo e($warranty->id); ?>", "<?php echo e($warranty->serial_number); ?>", {
        format: "CODE128",
        width: 2,
        height: 40,
        displayValue: true
    });
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\egeon\resources\views/distributor/check-warranty.blade.php ENDPATH**/ ?>